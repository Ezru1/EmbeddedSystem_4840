/*
 * Copyright (C) 2012 - 2014 Cisco Systems
 * Copyright (C) 2000 - 2007 Jeff Dike (jdike@{addtoit,linux.intel}.com)
 * Licensed under the GPL
 */

#ifndef __TIMER_INTERNAL_H__
#define __TIMER_INTERNAL_H__

#define TIMER_MULTIPLIER 256
#define TIMER_MIN_DELTA  500

#endif
