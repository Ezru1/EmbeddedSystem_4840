#ifndef _ASM_OPENRISC_SPINLOCK_TYPES_H
#define _ASM_OPENRISC_SPINLOCK_TYPES_H

#include <asm/qspinlock_types.h>
#include <asm/qrwlock_types.h>

#endif /* _ASM_OPENRISC_SPINLOCK_TYPES_H */
