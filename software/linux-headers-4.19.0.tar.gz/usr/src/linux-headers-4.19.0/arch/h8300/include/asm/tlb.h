/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __H8300_TLB_H__
#define __H8300_TLB_H__

#define tlb_flush(tlb)	do { } while (0)

#include <asm-generic/tlb.h>

#endif
