/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __H8300_BYTEORDER_H__
#define __H8300_BYTEORDER_H__

#include <linux/byteorder/big_endian.h>

#endif
