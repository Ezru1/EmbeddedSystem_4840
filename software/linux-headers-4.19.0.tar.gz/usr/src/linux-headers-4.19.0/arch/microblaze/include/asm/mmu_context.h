/* SPDX-License-Identifier: GPL-2.0 */
#ifdef CONFIG_MMU
# include <asm/mmu_context_mm.h>
#else
# include <asm-generic/mmu_context.h>
#endif
